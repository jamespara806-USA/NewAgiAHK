# No Unreal Engine or Pester required. Tests report acceptance/rejection only.
. "$PSScriptRoot/Windows.Common.ps1"
$testDirectory = Join-Path ([IO.Path]::GetTempPath()) ('ThresholdReportTest-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $testDirectory | Out-Null
$checks = 0
function Write-ReportFixture {
    param([string]$State = 'Success', [string]$Name = 'ThresholdRun.Smoke.GameLoop',
        [int]$Succeeded = 1, [int]$Failed = 0, [int]$NotRun = 0, [int]$InProcess = 0,
        [switch]$Empty)
    $testEntries = @(@{ fullTestPath = $Name; state = $State })
    if ($Empty) { $testEntries = @() }
    @{ tests = $testEntries; succeeded = $Succeeded; succeededWithWarnings = 0;
       failed = $Failed; notRun = $NotRun; inProcess = $InProcess } |
        ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $testDirectory 'index.json')
}
function Assert-Rejected {
    $rejected = $false
    try { Assert-ThresholdReport $testDirectory } catch { $rejected = $true }
    if (!$rejected) { throw 'Invalid/missing automation result was accepted' }
}
try {
    Write-ReportFixture
    Assert-ThresholdReport $testDirectory
    $checks++
    Write-ReportFixture -Empty -Succeeded 0
    Assert-Rejected
    $checks++
    Write-ReportFixture -State 'Fail' -Succeeded 0 -Failed 1
    Assert-Rejected
    $checks++
    Write-ReportFixture -State 'NotRun' -Succeeded 0 -NotRun 1
    Assert-Rejected
    $checks++
    Write-ReportFixture -State 'InProcess' -Succeeded 0 -InProcess 1
    Assert-Rejected
    $checks++
    Write-ReportFixture -Name 'Unrelated.Test'
    Assert-Rejected
    $checks++
    Remove-Item -LiteralPath (Join-Path $testDirectory 'index.json')
    Assert-Rejected
    $checks++
    '{invalid json' | Set-Content -LiteralPath (Join-Path $testDirectory 'index.json')
    Assert-Rejected
    $checks++
    Write-Host "PASS: $checks automation report validation checks (these are not gameplay tests)."
} finally {
    Remove-Item -LiteralPath $testDirectory -Recurse
}
