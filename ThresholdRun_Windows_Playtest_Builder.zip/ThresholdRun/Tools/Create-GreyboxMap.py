"""Run ONLY in Unreal Editor via Prepare-Windows.ps1; never overwrites a map."""
import json
import os
from pathlib import Path

import unreal


def prepare():
    receipt = Path(os.environ['THRESHOLD_MAP_RECEIPT'])
    content = Path(unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_content_dir()))
    map_file = content / 'Maps' / 'L_Greybox.umap'
    level = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
    actors = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    asset_path = '/Game/Maps/L_Greybox'
    created = not map_file.exists()
    if created:
        if not level.new_level(asset_path):
            raise RuntimeError('Could not create /Game/Maps/L_Greybox')
        start = actors.spawn_actor_from_class(
            unreal.PlayerStart, unreal.Vector(0, 0, 160), unreal.Rotator(0, 0, 0))
        if not start:
            raise RuntimeError('PlayerStart spawn failed')
        world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
        game_mode = unreal.load_class(None, '/Script/ThresholdRun.GreyGameMode')
        if not game_mode:
            raise RuntimeError('Native GreyGameMode was not compiled')
        world.get_world_settings().set_editor_property('default_game_mode', game_mode)
        if not level.save_current_level():
            raise RuntimeError('L_Greybox save failed')
    elif not level.load_level(asset_path):
        raise RuntimeError('Existing L_Greybox could not be loaded; it was not overwritten')

    starts = [a for a in actors.get_all_level_actors() if isinstance(a, unreal.PlayerStart)]
    if len(starts) != 1:
        raise RuntimeError('Expected exactly one PlayerStart; existing map was not changed')
    position = starts[0].get_actor_location()
    rotation = starts[0].get_actor_rotation()
    if max(abs(position.x), abs(position.y), abs(position.z - 160), abs(rotation.yaw)) > 0.1:
        raise RuntimeError('PlayerStart must be (0,0,160), yaw 0; existing map was not changed')
    if not map_file.is_file():
        raise RuntimeError('Saved map file is missing')
    receipt.write_text(json.dumps({'status': 'prepared', 'created': created, 'map': asset_path}), encoding='utf-8')
    unreal.log('ThresholdRun: L_Greybox map preparation succeeded')


# A missing receipt fails the PowerShell runner even if the editor exits with 0.
try:
    prepare()
finally:
    unreal.SystemLibrary.quit_editor()
