param(
    [Parameter(Mandatory=$true)][string]$EngineRoot,
    [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot),
    [switch]$Packaged,
    [ValidateRange(60,3600)][int]$TimeoutSeconds = 180,
    [switch]$Render
)
. "$PSScriptRoot\Windows.Common.ps1"
$paths = Get-ThresholdPaths $EngineRoot $ProjectRoot
$runRoot = Join-Path $paths.Project ('Saved\Automation\Smoke-' + [Guid]::NewGuid().ToString('N'))
$sandbox = Join-Path $runRoot 'User'
New-Item -ItemType Directory -Path $sandbox -Force | Out-Null
if ($Packaged) {
    # Launch the real binary directly so timeout/exit monitoring covers the game,
    # rather than the short-lived prerequisite/bootstrap executable.
    $executables = @(Get-ChildItem -LiteralPath (Join-Path $paths.Project 'Builds\Windows') `
        -Filter ThresholdRun.exe -Recurse | Where-Object { $_.FullName -match '[\\/]Binaries[\\/]Win64[\\/]' })
    if ($executables.Count -ne 1) { throw 'Expected one packaged game binary. Package first.' }
    $executable = $executables[0].FullName
    $prefix = @('/Game/Maps/L_Greybox')
} else {
    $executable = Join-Path $paths.Engine 'Engine\Binaries\Win64\UnrealEditor-Cmd.exe'
    $prefix = @($paths.UProject, '/Game/Maps/L_Greybox', '-game')
}

# A fresh process exercises TC1-3; a second process reuses only the isolated disk
# save and proves GameInstance::Init reloads permanent progress on application start.
foreach ($phase in @('Fresh', 'Restart')) {
    $report = Join-Path $runRoot $phase
    $receipt = Join-Path $sandbox "$phase.ok"
    $arguments = $prefix + @(
        '-unattended', '-nosplash', '-nosound', '-nop4', '-SaveToUserDir',
        "-UserDir=$sandbox", "-ThresholdSmokeRoot=$sandbox",
        '-ExecCmds=Automation RunTests ThresholdRun',
        '-TestExit=Automation Test Queue Empty', "-ReportExportPath=$report",
        "-abslog=$runRoot\$phase.log"
    )
    if (!$Render) { $arguments += '-NullRHI' }
    if ($phase -eq 'Restart') { $arguments += '-ThresholdSmokeRestart' }
    Write-Host "Running $phase smoke phase; log: $runRoot\$phase.log"
    Invoke-ThresholdProcess -FilePath $executable -Arguments $arguments -TimeoutSeconds $TimeoutSeconds
    Assert-ThresholdReport $report
    if (!(Test-Path -LiteralPath $receipt) -or (Get-Content -Raw -LiteralPath $receipt).Trim() -ne 'PASS') {
        throw "Missing success receipt for $phase; inspect the current report and log."
    }
}
Write-Host "PASS: TC1 spawn/vitals; TC2 switch/gate <=2s; TC3 oxygen death/reload/save; separate-process persistence."
Write-Host "Reports, logs and isolated save retained at $runRoot"
