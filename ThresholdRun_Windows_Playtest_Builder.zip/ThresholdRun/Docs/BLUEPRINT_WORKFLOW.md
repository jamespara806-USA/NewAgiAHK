# Blueprint extension guide — no C++ edits needed for art changes

## 1. Make designers' Blueprint actors

In Content Browser: right-click → **Blueprint Class** → **All Classes** (search native classes):

- `BP_PowerSwitch` → parent **SwitchMechanism**. Select `Visual` and set a real lever or handle Static Mesh, or add child meshes. Add a PointLight. In Event Graph, use **Event On Switch Used** → Set Light Color (green), Play Sound, animate a timeline. You can change `Energy Cost` in Class Defaults.
- `BP_ZoneGate` → parent **GreyGate**. Keep the `Barrier` mesh's blocking collision (until the native code opens it). In Event Graph, **Event On Gate Opened** → play particles/audio. The native class disables collision/hides barrier, so do not animate a blocking collider back in the way.
- `BP_RewardPickup` → parent **GreyPickup**. Use **Event On Collected** for feedback. The native class handles permanent save and destroys the actor afterward.
- `BP_PressurePlate` → parent **PressurePlate**. Customize `Visual` but preserve `PressureArea` trigger geometry. Blueprint child does not need overlap nodes: native `OnEnter/OnExit` already calls the puzzle FSM.

All interactions pass through `UPrototypeInteractable` as BlueprintNativeEvents. If overriding `Interact` in a Blueprint, **Call to Parent Function** unless replacing C++ resource spend/state change intentionally.

## 2. Tell the generator to instantiate BP variants

- Create `BP_WorldBuilder` subclass of **GreyWorldBuilder**. In Class Defaults set `Switch Class=BP_PowerSwitch`, `Gate Class=BP_ZoneGate`, `Plate Class=BP_PressurePlate`, `Pickup Class=BP_RewardPickup` and optionally an Exit BP.
- Place exactly **one `BP_WorldBuilder`** actor in `L_Greybox`. `GreyGameMode` searches for an existing builder, and will *not* auto-create a native one if your BP builder exists.
- Press Play. The same C++ run graph now uses your BP actor classes, but you still don't need a Blueprint for the GameMode or the player.
- To inspect mechanics in the editor, use eject/possess during PIE and inspect runtime spawned actors. Do not expect generated blocks to persist after exiting Play.

## 3. Example new BP puzzle (light reflector)

Blueprint Class `BP_Mirror` → parent **PuzzleMechanism**. Add `SceneComponent` pivot + mirror mesh + collision. On custom `RotateMirror` event, evaluate light-ray intersection, then call `TryActivate` (when aligned) and `TryTrigger` (when beam hits receiver). For interaction, either derive from a C++ interactable mechanism class or create a native actor implementing `UPrototypeInteractable`; Blueprint-only actor interface implementation can also call the engine interface if set up via Class Settings → Implemented Interfaces, but requires an interaction collision surface.

Use `OnStateChanged` from the native mechanism to drive light colors and sounds. For authored puzzle chains, add a BP relay with `Configure` called by a room blueprint on BeginPlay. Don't create cycles between relays.

## 4. UI follow-up

`GreyHUD` currently uses AHUD Canvas for clarity and zero UMG asset dependencies. For a production-looking HUD: create `WBP_HUD` with progress bars bound to the player `SurvivalVitals`, look prompt bound to `GetInteractionPrompt`, and run count bound to `GreyGameInstance`. Spawn in a custom `PlayerController` `BeginPlay`. At that point, remove the prototype `GreyHUD` or disable its `DrawHUD` drawing to avoid duplicate overlays.
