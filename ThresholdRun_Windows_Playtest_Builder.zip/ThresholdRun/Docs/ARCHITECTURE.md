# Architecture & state ownership

## Lifetimes and communication

```
GameInstance (persists across OpenLevel)
  GreyMetaSave [USaveGame] ── SaveGameToSlot ── disk
  GetRunSeed() ──► GreyWorldBuilder [BeginPlay]
                      │
GameMode [one level]   ├── Hub 0 ──(gate 1)── Hub 1 ──(gate 2)── Hub 2
 EndRun(bool)          │                 ▲                    ▲
  └── OpenLevel ◄──── player death    switch 1           switch 2 + plate
          ▲                                            └── AND relay (latches)
          └──── exit's Interact() ──────────────────────────────────┘

GreyPlayer [spawned each run] ── EnhancedInput ── movement
    │                          └── raycast, first blocking hit only
    ├── UPrototypeInteractable::Execute_Interact(Actor)
    └── SurvivalVitals::OnDied() ── GameMode::EndRun(false)

GreyGate::Configure(PuzzleMechanism*, ShortcutID)
  ├── PuzzleMechanism::OnStateChanged delegate
  └── GreyGameInstance::HasShortcut(ShortcutID)
```

**Ownership rules**: Engine `GameInstance` stores permanent progress and current run seed across level reloads. `GameMode` is level-scoped and is the single authority for the run-ending guard (`bEnding`). `GreyWorldBuilder` owns geometry and native actor instantiation; the engine destroys those actors when the level reloads. `AGreyPlayer` holds vital stats only for that run. No puzzle knows about input mappings; no input code knows which puzzle type it hit.

## Puzzle state design

`APuzzleMechanism` owns flags `bLocked`, `bPowered`, `bActivated`, `bTriggered`. Presented state priority: `Triggered > Locked > Unpowered > Activated > Ready`. `TryActivate` requires Ready and `TryTrigger` requires Activated. `RefreshState` broadcasts `OnStateChanged(Mechanism, Old, New)` only when the effective state changes. `APressurePlate` resets when no player occupies its trigger, but `ALogicRelay` latches after its AND prerequisites are satisfied. This avoids stranding the player after leaving the plate.

**MVP limitations**: `APlayer` standing on a pressure plate counts as weight. There is no crate/push mechanic yet. The relay source graph is manually constructed as a DAG. For future general authoring, add cycle detection at graph compile time. Designers should not configure a relay as its own upstream dependency.

## Geometry & progression invariant

- Hub centers are `X={0,2200,4400}` with floors `1900 × 1400` cm, fixed main spine. Gate 1 at `X=1100`, gate 2 at `X=3300`. Only the optional room (hub 2's side cache) and one switch offset vary with seed.
- Each gate's required puzzle parts are strictly on its **source** side. This guarantees that mandatory prerequisites aren't placed behind their own door.
- Optional cache is side content: no required key is hidden in it. Variability is **limited** and does not amount to full procedural open-world topology.
- During runs, `GreyWorldBuilder` assembles Engine BasicShapes cubes, so no cooked art assets are required for greyboxing.
- Every openable gate checks both current run's puzzle and persisted `FName` shortcut ID. Use stable logical IDs, **never generated coordinates**, for permanent shortcuts.

## Data & reset table

| Datum | Owner | On death | On escape |
|---|---|---|---|
| Player position / energy / warmth / oxygen | Pawn, Vitals | Reset | Reset |
| Puzzle state, consumables, open door flags | Level actors | Reset | Reset |
| Shortcut `shortcut_gate_1` | GreyMetaSave | Retain | Retain |
| Blueprint `blueprint_thermal_lens` | GreyMetaSave | Retain | Retain |
| Runs completed, wins, next deterministic seed | GreyMetaSave | Increment + save | Increment + save |

Persistence uses one slot `ThresholdRunMeta_v1`, user index 0. If a save write fails, an error is logged; the prototype does not offer transactional recovery or a save error screen. Use a new slot name to test from scratch rather than deleting production game saves.

## Extension boundary

Each interactive actor uses BlueprintNativeEvent interface methods so Blueprint subclasses can override `CanInteract`, `InteractionLabel` and `Interact` without modifying the raycast system. `ASwitchMechanism::OnSwitchUsed`, `AGreyGate::OnGateOpened`, and `AGreyPickup::OnCollected` are BlueprintImplementableEvent hooks for VFX/audio. `GreyWorldBuilder` exposes actor class overrides (`SwitchClass`, `PlateClass`, etc.), so designers can replace the default native meshes with BP children while leaving wiring in C++.
