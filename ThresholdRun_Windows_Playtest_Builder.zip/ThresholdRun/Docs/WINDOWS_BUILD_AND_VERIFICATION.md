# Windows Development build and automated verification

For a single-launcher build on a Windows PC with UE 5.8, start with
`START_HERE.md` and double-click `Build-Playtest.cmd`. It prepares the map,
packages the game, verifies the packaged smoke test plus restart persistence,
and creates a ZIP of the complete playable archive. The commands below remain
available for running each stage separately.

These additions target the uploaded **UE 5.8** starter. `ASwitchMechanism` and
`AGreyGate` are the actual switch/gate classes (the earlier APowerSwitch and
AZoneGate names do not exist in this project). No gameplay source from the
starter was changed. A native Automation test was added to the runtime module;
there is no map-placed test actor or unimplemented gameplay adapter.

## Current validation boundary

This cloud host is Linux without Unreal Engine, MSVC or the Windows SDK. No
Windows executable, UHT/UBT compile, generated map, gameplay pass, or performance
result is claimed. The Windows commands below must be run with the installed
engine. Script parsing, report-validation tests, the supplied source validator,
and preservation of the original archive files are checked separately here.

## Windows prerequisites and commands

Install UE **5.8** with Win64 support, its supported Visual Studio C++ toolchain,
and Windows SDK. The starter requests Visual Studio 2022 Game development with
C++; check your engine installation's toolchain requirements. No Marketplace
assets, credentials, backend services or extra project package installs are
required. Leave `Source`, `Config`, `Content` and `Tools` together beside the
uproject. Use the existing checkout; do not create a worktree unless requested.

From a PowerShell terminal in the project root:

```powershell
$engine = 'C:\Program Files\Epic Games\UE_5.8'
.\Tools\Prepare-Windows.ps1 -EngineRoot $engine
.\Tools\Run-SmokeTests.ps1 -EngineRoot $engine
.\Tools\Package-Windows.ps1 -EngineRoot $engine
.\Tools\Run-SmokeTests.ps1 -EngineRoot $engine -Packaged
```

`Prepare-Windows.ps1` builds **ThresholdRunEditor / Win64 / Development**, then
runs `Create-GreyboxMap.py` inside Unreal Editor. It temporarily enables the
engine's PythonScriptPlugin on that command line, without editing the uproject.
The script creates `/Game/Maps/L_Greybox`, a PlayerStart at `(0,0,160)` / yaw 0,
and the GreyGameMode override. An existing map is loaded and validated rather
than overwritten. A unique receipt and editor log are retained under
`Saved/Automation/Map-*`. If Python scripting is unavailable, use the manual map
steps in `SETUP_AND_SMOKE_TEST.md`, then run the smoke command.

The new `Config/Windows/WindowsEngine.ini` sets the editor and game default map
on Windows; the original DefaultEngine.ini is unchanged. All three regions and
the optional cache are assembled in this one map at BeginPlay. There are no
additional region maps to cook.

The editor build defaults to eight compiler actions; use
`-MaxParallelActions 2` on a memory-constrained Windows machine. Keep sufficient
disk space for the engine, intermediate files, shader cache and archive. The
packaging command builds the separate game target as required; it reuses valid
UBT/cook outputs. Move any prior nonempty `Builds/Windows` archive aside before
packaging; the script refuses to mix artifacts from different builds.

Equivalent exact UAT command, from the project root in **cmd.exe** with UE_ROOT
set to the engine installation directory:

```bat
"%UE_ROOT%\Engine\Build\BatchFiles\RunUAT.bat" BuildCookRun -project="%CD%\ThresholdRun.uproject" -noP4 -platform=Win64 -clientconfig=Development -build -cook -map=/Game/Maps/L_Greybox -stage -pak -package -archive -archivedirectory="%CD%\Builds\Windows" -prereqs -utf8output -unattended
```

Output is **`./Builds/Windows/`** relative to the project. Typical UE archive
layout places the bootstrap EXE at `Builds/Windows/Windows/ThresholdRun.exe` and
the game binary at `Windows/ThresholdRun/Binaries/Win64/ThresholdRun.exe` beneath
the archive. Distribute the complete archive directory, including content and
prerequisites. The EXE alone does not contain the cooked game.

## Automation behavior and invocation

`Source/ThresholdRun/Tests/ThresholdSmokeTests.cpp` registers one ordered
integration test, **`ThresholdRun.Smoke.GameLoop`**, covering the three requested
cases. The test runs in a game world, outside PIE, and requires no placed driver
actor. Its latent command survives destruction of the old map during OpenLevel.

1. **TC1:** player 0 possesses AGreyPlayer; its registered SurvivalVitals has
   Energy/Oxygen/Warmth=100 and is alive. The correct map, GameMode and
   GameInstance must be present.
2. **TC2:** gate 1 starts closed and switch 1 starts Ready. The driver positions
   and aims the player at the seeded switch location, verifies the production
   camera trace hits it, then calls `AGreyPlayer::TryInteract`. It asserts a
   12-energy cost, a triggered switch, and an invisible, nonblocking gate within
   two wall-clock seconds. It does not synthesize the physical E key.
3. **TC3:** production unlock methods save `shortcut_gate_1` and
   `blueprint_thermal_lens`; an independent LoadGameFromSlot verifies the disk
   fixture. AddExposure drains oxygen through normal component ticks to zero.
   The test observes death with energy/warmth still positive and waits for
   GameMode's actual delayed map reload. It never invokes OpenLevel itself.
   It requires a new world/player, restored vitals, RunsCompleted=1,
   Victories=0, seed=20264, saved unlocks, gate 1 open without reusing the switch,
   and gate 2 closed with its switch reset.

The runner starts **a second application process** with the same isolated save.
The same registered test switches to restart verification using
`-ThresholdSmokeRestart`: the new GameInstance must load the disk progress,
apply the shortcut, and restore the saved run number/seed. This proves more than
an in-process GameInstance cache surviving map reload.

The game hardcodes slot `ThresholdRunMeta_v1`, user index 0. The runner therefore
creates a fresh sandbox per invocation and uses both `-UserDir` and
`-SaveToUserDir`. The C++ test verifies that the actual `ProjectSavedDir` falls
under that sandbox **before any save writes**. Ordinary player saves are not
renamed, deleted or overwritten. Logs, JSON reports, receipts and isolated saves
remain under `Saved/Automation/Smoke-<unique-id>` for inspection. Keep the sandbox
until evidence has been reviewed; rerunning creates another fresh one.

An equivalent editor-hosted command (PowerShell) shows the exact automation
launch flags. Create a fresh absolute `$sandbox` and `$report` path first:

```powershell
& "$engine\Engine\Binaries\Win64\UnrealEditor-Cmd.exe" `
  "$PWD\ThresholdRun.uproject" /Game/Maps/L_Greybox -game -unattended -NullRHI `
  -SaveToUserDir "-UserDir=$sandbox" "-ThresholdSmokeRoot=$sandbox" `
  '-ExecCmds=Automation RunTests ThresholdRun' `
  '-TestExit=Automation Test Queue Empty' "-ReportExportPath=$report"
```

`Run-SmokeTests.ps1` supplies these paths, a unique report per phase and a
180-second process timeout (adjust with `-TimeoutSeconds`). It launches the
packaged **inner game binary** so process monitoring covers the game, rather
than the bootstrapper. Each phase must exit with code 0, export a current
`index.json` containing exactly the expected test with Success, have no failed,
unrun or in-process cases, and produce its success receipt. Zero discovered
tests, missing reports, crashes and timeouts fail verification. The three TC
markers appear in the Fresh log; restart success appears in Restart.log.

Tests are guarded by `WITH_DEV_AUTOMATION_TESTS` in the runtime module and need
only its existing module dependencies. They are intended for Development
targets. If a custom target disables development automation, enable it for the
test build; the runner will reject a zero-test run. Do not use Shipping for this
workflow. `-Render` removes NullRHI, but the smoke test still does not measure
playable frame performance or prove all traversal/collision behavior.

## Playable executable acceptance protocol

Record build revision, engine version, CPU/GPU, resolution and graphics preset,
plus your chosen FPS/frame-time budget. The starter defines no numeric
performance acceptance budget. Use a dedicated test account or backed-up save;
do not delete or modify a real player's slot. For a clean manual run you can
also pass `-SaveToUserDir -UserDir="D:\ThresholdRunManualTest"`; reuse that same
directory for the restart check.

1. Launch the archived **bootstrap ThresholdRun.exe** with `-log`. Confirm
   L_Greybox starts without an explicit map argument, the generated rooms are
   visible, and the player stands on the floor. Verify WASD, mouse look, jump,
   sprint, crouch, resource HUD and the 310 cm first-hit interaction prompt.
2. **Furnace:** approach switch 1 near `(430,-240)` (its Y varies by seed), aim
   at its cube and press E. Verify 12 energy spent and gate 1 at `(1100,0)` opens
   within two seconds and is physically traversable. A blocking wall must
   prevent interaction through it. An existing shortcut may already open it;
   use a fresh manual sandbox for this initial case.
3. **Floodgates:** collect the permanent shortcut at `(1575,-360)` and blueprint
   at `(2140,-420)` by aiming and pressing E; they are interactable pickups,
   not automatic overlap collectibles. Activate switch 2 `(2520,-265)` and
   stand on plate `(2580,240)`. Gate 2 `(3300,0)` must remain shut with either
   input alone and latch open with both. Leave the plate and cross the gate.
4. **Observatory:** traverse the freezing area near `(3980,0)`, verify warmth
   decreases, collect the warmth pickup `(4340,-360)` if needed, and interact
   with the exit `(4870,0)`. After roughly 1.5 seconds the map reloads, run
   number/seed advance, and gate 1 starts open. Blueprint and shortcut persist.
5. On a separate run, remain in the freezing zone until warmth reaches zero.
   Confirm death/reload and retained unlocks. Oxygen has no naturally draining
   zone in this starter; its death path is exercised by TC3's exposure fixture.
6. For representative performance, use the Development console `stat unit`,
   `stat fps`, then `stat startfile`; perform a complete three-region run and
   `stat stopfile`. Retain the `.ue4stats` capture under
   `Saved/Profiling/UnrealStats`. Compare CPU/GPU frame time and traversal hitches
   with the agreed budget. The ordinary game log alone is not a performance
   profile.
7. Inspect the current **`Saved/Logs/ThresholdRun.log`** for Fatal/Error/Ensure,
   travel failures, missing packages, save load/write failures and unexpected
   run resets. Depending on launch mode, Saved may be beside the packaged game,
   under `%LOCALAPPDATA%\ThresholdRun`, or under the explicit UserDir. Confirm
   the timestamp and build before interpreting a log.
8. Exit normally and wait until the application terminates. Relaunch under the
   same account and save directory. Confirm shortcut_gate_1 still bypasses
   gate 1, the blueprint remains learned, run number and seed are retained,
   and vitals/puzzle state reset. Complete another run using the shortcut.
9. Archive logs, current automation reports, performance captures, save-state
   observations, and a pass/fail checklist alongside the packaged build.

Required readiness evidence: Editor and Game compilation, TC1-3 plus restart
verification in the packaged Development build, and one successful manual
three-region run. Performance profiling is needed to assess the chosen budget;
Blueprint art/VFX overrides and future physics-crate puzzles are optional.
