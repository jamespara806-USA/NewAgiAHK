@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Tools\Build-Playtest.ps1" %*
set "threshold_result=%ERRORLEVEL%"
if not "%threshold_result%"=="0" echo Playtest build stopped. Read the error above; a verified playable build was not produced.
pause
exit /b %threshold_result%
