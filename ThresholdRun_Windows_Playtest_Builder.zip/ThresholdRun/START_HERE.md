# Build your Windows playtest

This download contains the game source and build launcher. It does **not**
contain an already compiled EXE. Build it on your Windows PC with UE 5.8 and
the supported Visual Studio C++ toolchain / Windows SDK installed.

1. Extract the entire ZIP to a normal local folder, outside the ZIP viewer.
2. Double-click **Build-Playtest.cmd** beside ThresholdRun.uproject.
3. Wait for compilation, map preparation, packaging and the automated tests.
   The terminal stays open if an error occurs. The first build can take time.
4. After all checks pass, Explorer selects **ThresholdRun.exe**. Double-click
   that file to play. A separate `ThresholdRun-Windows-Playtest-*.zip` under
   **Builds** contains the complete playable build for sharing. Anyone playing
   that completed build must extract the whole ZIP before launching its EXE;
   they do not need Unreal Editor.

The launcher checks UE_ROOT, the UE 5.8 installation registry entry and the
normal Epic Games installation directory. If UE is installed elsewhere, run:

```bat
Build-Playtest.cmd -EngineRoot "D:\Epic Games\UE_5.8"
```

If the build reports a missing C++ compiler or Windows SDK, install Visual
Studio's **Game development with C++** workload and the compiler/SDK versions
required by UE 5.8, then run the launcher again. The launcher uses a temporary
PowerShell execution policy for its own process; it does not change your
machine's execution policy. Existing build archives are preserved under
`Builds/Windows-previous-*` on subsequent runs.

Controls: WASD move, mouse look, Shift sprint, Ctrl crouch, Space jump, E interact.
Activate the first switch, collect the shortcut and blueprint in region 2,
activate its switch and stand on the plate, then cross the freezing region and
interact with the exit. Progress persists in the normal SaveGame slot during
manual play; automated tests use a separate save directory.

The Windows build and gameplay cannot be verified from the Linux cloud host.
If the launcher fails, keep the complete terminal error and the newest
`Saved/Automation` logs. The detailed build/test protocol is in
`Docs/WINDOWS_BUILD_AND_VERIFICATION.md`.
