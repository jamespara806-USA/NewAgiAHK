using UnrealBuildTool;
using System.Collections.Generic;
public class ThresholdRunEditorTarget : TargetRules
{
    public ThresholdRunEditorTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Editor;
        DefaultBuildSettings = BuildSettingsVersion.V5;
        IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
        ExtraModuleNames.Add("ThresholdRun");
    }
}
