#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "InputActionValue.h"
#include "GreyPlayer.generated.h"
class UCameraComponent;
class USurvivalVitals;
class UInputMappingContext;
class UInputAction;
UCLASS(Blueprintable)
class THRESHOLDRUN_API AGreyPlayer : public ACharacter
{
    GENERATED_BODY()
public:
    AGreyPlayer();
    virtual void BeginPlay() override;
    virtual void Tick(float DeltaSeconds) override;
    virtual void SetupPlayerInputComponent(UInputComponent* Input) override;
    UPROPERTY(VisibleAnywhere,BlueprintReadOnly) TObjectPtr<UCameraComponent> Camera;
    UPROPERTY(VisibleAnywhere,BlueprintReadOnly) TObjectPtr<USurvivalVitals> Vitals;
    UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Movement") float WalkSpeed=410.f;
    UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Movement") float SprintSpeed=650.f;
    UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Interaction") float InteractDistance=310.f;
    UFUNCTION(BlueprintPure) AActor* FindInteractable() const;
    UFUNCTION(BlueprintPure) FText GetInteractionPrompt() const;
    UFUNCTION(BlueprintCallable) void TryInteract();
private:
    UPROPERTY(Transient) TObjectPtr<UInputMappingContext> RuntimeMappings;
    UPROPERTY(Transient) TObjectPtr<UInputAction> ForwardAction;
    UPROPERTY(Transient) TObjectPtr<UInputAction> RightAction;
    UPROPERTY(Transient) TObjectPtr<UInputAction> YawAction;
    UPROPERTY(Transient) TObjectPtr<UInputAction> PitchAction;
    UPROPERTY(Transient) TObjectPtr<UInputAction> JumpAction;
    UPROPERTY(Transient) TObjectPtr<UInputAction> SprintAction;
    UPROPERTY(Transient) TObjectPtr<UInputAction> CrouchAction;
    UPROPERTY(Transient) TObjectPtr<UInputAction> InteractAction;
    bool bWantsSprint=false;
    void Forward(const FInputActionValue& Value);
    void Right(const FInputActionValue& Value);
    void Yaw(const FInputActionValue& Value);
    void Pitch(const FInputActionValue& Value);
    void StartSprint(const FInputActionValue& Value);
    void EndSprint(const FInputActionValue& Value);
    void StartJump(const FInputActionValue& Value);
    void StopJumpAction(const FInputActionValue& Value);
    void ToggleCrouch(const FInputActionValue& Value);
    void InteractPressed(const FInputActionValue& Value);
    UFUNCTION() void OnVitalsDeath();
};
