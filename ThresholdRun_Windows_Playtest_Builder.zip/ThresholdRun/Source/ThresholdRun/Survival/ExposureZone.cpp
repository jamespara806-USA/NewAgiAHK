#include "Survival/ExposureZone.h"
#include "Survival/SurvivalVitals.h"
#include "Components/BoxComponent.h"
AExposureZone::AExposureZone()
{
    Trigger = CreateDefaultSubobject<UBoxComponent>(TEXT("HazardTrigger"));
    SetRootComponent(Trigger);
    Trigger->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
    Trigger->SetCollisionResponseToAllChannels(ECR_Ignore);
    Trigger->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);
    Trigger->SetGenerateOverlapEvents(true);
}
void AExposureZone::BeginPlay()
{
    Super::BeginPlay(); Trigger->SetBoxExtent(BoxExtent);
    Trigger->OnComponentBeginOverlap.AddDynamic(this, &AExposureZone::Enter);
    Trigger->OnComponentEndOverlap.AddDynamic(this, &AExposureZone::Exit);
}
void AExposureZone::Enter(UPrimitiveComponent*, AActor* Actor, UPrimitiveComponent*, int32, bool, const FHitResult&)
{
    if (USurvivalVitals* V = Actor ? Actor->FindComponentByClass<USurvivalVitals>() : nullptr)
    { if (!Occupants.Contains(V)) { Occupants.Add(V); V->AddExposure(OxygenDrainPerSecond, WarmthDrainPerSecond); } }
}
void AExposureZone::Exit(UPrimitiveComponent*, AActor* Actor, UPrimitiveComponent*, int32)
{
    if (USurvivalVitals* V = Actor ? Actor->FindComponentByClass<USurvivalVitals>() : nullptr)
    { if (Occupants.Remove(V) > 0) V->RemoveExposure(OxygenDrainPerSecond, WarmthDrainPerSecond); }
}
void AExposureZone::EndPlay(const EEndPlayReason::Type Reason)
{
    for (USurvivalVitals* V : Occupants)
        if (IsValid(V)) V->RemoveExposure(OxygenDrainPerSecond, WarmthDrainPerSecond);
    Occupants.Empty(); Super::EndPlay(Reason);
}
