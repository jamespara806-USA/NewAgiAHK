#include "World/GreyWorldBuilder.h"
#include "Puzzles/SwitchMechanism.h"
#include "Puzzles/PressurePlate.h"
#include "Puzzles/LogicRelay.h"
#include "Puzzles/GreyGate.h"
#include "Progression/GreyPickup.h"
#include "Progression/GreyExit.h"
#include "Progression/GreyGameInstance.h"
#include "Survival/ExposureZone.h"
#include "Engine/StaticMeshActor.h"
#include "Engine/TextRenderActor.h"
#include "Components/StaticMeshComponent.h"
#include "Components/TextRenderComponent.h"
#include "Engine/World.h"
#include "Engine/PointLight.h"
#include "Components/PointLightComponent.h"

AGreyWorldBuilder::AGreyWorldBuilder()
{
    PrimaryActorTick.bCanEverTick=false;
    // Visual Blueprints are optional. The native classes form a functioning fallback.
}
AActor* AGreyWorldBuilder::Block(const FVector& Center,const FVector& Dimensions)
{
    FActorSpawnParameters P;
    P.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
    AStaticMeshActor* A=GetWorld()->SpawnActor<AStaticMeshActor>(Center,FRotator::ZeroRotator,P);
    if (!A) return nullptr;
    UStaticMeshComponent* M=A->GetStaticMeshComponent();
    M->SetMobility(EComponentMobility::Movable);
    static UStaticMesh* Cube=LoadObject<UStaticMesh>(nullptr,TEXT("/Engine/BasicShapes/Cube.Cube"));
    if (Cube) M->SetStaticMesh(Cube);
    M->SetWorldScale3D(Dimensions/100.f);
    M->SetCollisionProfileName(TEXT("BlockAll"));
    return A;
}
void AGreyWorldBuilder::Sign(const FString& Text,const FVector& Location,const FColor& Color)
{
    ATextRenderActor* T=GetWorld()->SpawnActor<ATextRenderActor>(Location,FRotator(0,180,0));
    if (!T) return;
    UTextRenderComponent* C=T->GetTextRender();
    C->SetText(FText::FromString(Text)); C->SetTextRenderColor(Color);
    C->SetWorldSize(42.f); C->SetHorizontalAlignment(EHTA_Center);
}
void AGreyWorldBuilder::MakeRoom(int32 Slot,bool bBranch)
{
    const float X=Slot*2200.f;
    Block(FVector(X,0,-50),FVector(1900,1400,100));
    // Long walls. Slot 1 makes a north-wall portal only if its optional branch is present.
    Block(FVector(X,-700,165),FVector(1900,70,330));
    if (Slot==1 && bBranch)
    {
        Block(FVector(X-600,700,165),FVector(700,70,330));
        Block(FVector(X+600,700,165),FVector(700,70,330));
    }
    else Block(FVector(X,700,165),FVector(1900,70,330));
    for (int32 Side=-1;Side<=1;Side+=2)
    {
        const bool bOpening=(Side>0 && Slot<2)||(Side<0 && Slot>0);
        const float SideX=X+Side*950.f;
        if (!bOpening) Block(FVector(SideX,0,165),FVector(70,1400,330));
        else
        {
            Block(FVector(SideX,-475,165),FVector(70,450,330));
            Block(FVector(SideX,475,165),FVector(70,450,330));
        }
    }
}
void AGreyWorldBuilder::MakeOptionalBranch()
{
    const float X=2200.f;
    Block(FVector(X,905,-50),FVector(500,410,100)); // connecting passage
    Block(FVector(X-250,905,165),FVector(70,410,330));
    Block(FVector(X+250,905,165),FVector(70,410,330));
    Block(FVector(X,1500,-50),FVector(850,800,100));
    Block(FVector(X-425,1500,165),FVector(70,800,330));
    Block(FVector(X+425,1500,165),FVector(70,800,330));
    Block(FVector(X,1900,165),FVector(850,70,330));
    Block(FVector(X-337.5f,1100,165),FVector(175,70,330));
    Block(FVector(X+337.5f,1100,165),FVector(175,70,330));
    Sign(TEXT("OPTIONAL CACHE"),FVector(X,1700,220),FColor::Yellow);
    if (AGreyPickup* P=SpawnPiece<AGreyPickup>(PickupClass,FVector(X,1550,55)))
        P->Configure(EPickupKind::Energy,NAME_None,45.f);
}
void AGreyWorldBuilder::BeginPlay()
{
    Super::BeginPlay();
    const UGreyGameInstance* GI=Cast<UGreyGameInstance>(GetGameInstance());
    FRandomStream Random(GI ? GI->GetRunSeed() : 12345);
    const bool bBranch=bAllowOptionalBranch && Random.FRand() > 0.36f;
    for(int32 I=0; I<3; ++I)
    {
        MakeRoom(I,bBranch);
        // An Empty Level has no light actors. Spawn lights to keep the prototype visible.
        if (APointLight* Light=GetWorld()->SpawnActor<APointLight>(FVector(I*2200.f,0,420),FRotator::ZeroRotator))
        {
            Light->GetPointLightComponent()->SetIntensity(45000.f);
            Light->GetPointLightComponent()->SetAttenuationRadius(2400.f);
        }
    }
    if (bBranch) MakeOptionalBranch();
    for (int32 I=0;I<2;++I)
    {
        const float CX=1100.f+I*2200.f;
        Block(FVector(CX,0,-50),FVector(300,500,100));
        Block(FVector(CX,-250,165),FVector(300,70,330));
        Block(FVector(CX,250,165),FVector(300,70,330));
    }
    Sign(TEXT("HUB 1: FURNACE / POWER SWITCH"),FVector(100,0,290));
    Sign(TEXT("HUB 2: PLATE + SWITCH = POWER"),FVector(1850,0,290));
    Sign(TEXT("HUB 3: COLD HAZARD / EXIT"),FVector(4020,0,290));
    const float Offset=Random.RandRange(-100,100);
    ASwitchMechanism* First=SpawnPiece<ASwitchMechanism>(SwitchClass,FVector(430,Offset-240,65));
    if (First) { First->SetCaptionText(TEXT("GATE 1 POWER SWITCH")); First->EnergyCost=12.f; }
    AGreyGate* Gate1=SpawnPiece<AGreyGate>(GateClass,FVector(1100,0,155));
    if (Gate1) Gate1->Configure(First,TEXT("shortcut_gate_1"));
    if (AGreyPickup* Shortcut=SpawnPiece<AGreyPickup>(PickupClass,FVector(1575,-360,55)))
        Shortcut->Configure(EPickupKind::Shortcut,TEXT("shortcut_gate_1"));
    if (AGreyPickup* Blueprint=SpawnPiece<AGreyPickup>(PickupClass,FVector(2140,-420,55)))
        Blueprint->Configure(EPickupKind::Blueprint,TEXT("blueprint_thermal_lens"));
    ASwitchMechanism* Second=SpawnPiece<ASwitchMechanism>(SwitchClass,FVector(2520,-265,65));
    if (Second) { Second->EnergyCost=15.f; Second->SetCaptionText(TEXT("GATE 2 POWER SWITCH")); }
    APressurePlate* Plate=SpawnPiece<APressurePlate>(PlateClass,FVector(2580,240,8));
    ALogicRelay* Relay=GetWorld()->SpawnActor<ALogicRelay>(FVector(2850,0,80),FRotator::ZeroRotator);
    if (Relay && Second && Plate)
    {
        TArray<APuzzleMechanism*> Inputs; Inputs.Add(Second); Inputs.Add(Plate);
        Relay->Configure(Inputs,true);
    }
    AGreyGate* Gate2=SpawnPiece<AGreyGate>(GateClass,FVector(3300,0,155));
    if (Gate2) Gate2->Configure(Relay,NAME_None);
    // The hazard is visible via signage, not via an art VFX asset.
    AExposureZone* Cold=GetWorld()->SpawnActor<AExposureZone>(FVector(3980,0,130),FRotator::ZeroRotator);
    if (Cold) {Cold->WarmthDrainPerSecond=17.f;Cold->BoxExtent=FVector(400,620,200);}
    Sign(TEXT("WARNING: FREEZING EXPOSURE"),FVector(3710,0,230),FColor::Red);
    if (AGreyPickup* Warm=SpawnPiece<AGreyPickup>(PickupClass,FVector(4340,-360,55)))
        Warm->Configure(EPickupKind::Warmth,NAME_None,55.f);
    SpawnPiece<AGreyExit>(ExitClass,FVector(4870,0,125));
}
