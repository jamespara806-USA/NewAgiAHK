#pragma once
#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "PrototypeInteractable.generated.h"
class APawn;

UINTERFACE(BlueprintType)
class UPrototypeInteractable : public UInterface
{
    GENERATED_BODY()
};

class THRESHOLDRUN_API IPrototypeInteractable
{
    GENERATED_BODY()
public:
    UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category="Interaction")
    bool CanInteract(APawn* Pawn) const;
    UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category="Interaction")
    FText InteractionLabel(APawn* Pawn) const;
    UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category="Interaction")
    void Interact(APawn* Pawn);
};
