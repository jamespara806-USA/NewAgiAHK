#pragma once
#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "GreyHUD.generated.h"
UCLASS(Blueprintable)
class THRESHOLDRUN_API AGreyHUD : public AHUD
{
    GENERATED_BODY()
public:
    virtual void DrawHUD() override;
};
