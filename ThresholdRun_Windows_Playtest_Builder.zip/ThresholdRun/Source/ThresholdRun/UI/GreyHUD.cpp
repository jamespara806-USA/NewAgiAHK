#include "UI/GreyHUD.h"
#include "Player/GreyPlayer.h"
#include "Progression/GreyGameInstance.h"
#include "Survival/SurvivalVitals.h"
#include "Engine/Canvas.h"
#include "Engine/Engine.h"
#include "GameFramework/PlayerController.h"
void AGreyHUD::DrawHUD()
{
    Super::DrawHUD();
    if (!Canvas || !GEngine || !PlayerOwner) return;
    const float X=Canvas->SizeX*0.5f, Y=Canvas->SizeY*0.5f;
    DrawLine(X-8,Y,X+8,Y,FLinearColor::White,1.5f);
    DrawLine(X,Y-8,X,Y+8,FLinearColor::White,1.5f);
    AGreyPlayer* P=Cast<AGreyPlayer>(PlayerOwner->GetPawn());
    UGreyGameInstance* GI=Cast<UGreyGameInstance>(GetGameInstance());
    if (GI)
    {
        DrawText(FString::Printf(TEXT("THRESHOLD RUN  |  Run %d  |  Seed %d"),GI->GetRunNumber(),GI->GetRunSeed()), FLinearColor::White,20,20,GEngine->GetSmallFont(),1.35f);
        DrawText(GI->GetRunMessage(),FLinearColor::Yellow,20,48,GEngine->GetSmallFont(),1.05f);
    }
    if (!P || !P->Vitals) return;
    const USurvivalVitals* V=P->Vitals;
    DrawText(FString::Printf(TEXT("ENERGY %.0f    OXYGEN %.0f    WARMTH %.0f"),V->Energy,V->Oxygen,V->Warmth),FLinearColor::Green,20,85,GEngine->GetSmallFont(),1.4f);
    DrawText(TEXT("WASD move  |  Mouse look  |  Shift sprint  |  Ctrl crouch  |  Space jump  |  E interact"),FLinearColor::White,20,118,GEngine->GetSmallFont(),1.05f);
    const float PX=P->GetActorLocation().X;
    const TCHAR* Objective=PX < 1250 ? TEXT("OBJECTIVE: Find gate 1 switch, then go east.")
                              : PX < 3450 ? TEXT("OBJECTIVE: Activate switch 2 AND stand on its pressure plate.")
                                          : TEXT("OBJECTIVE: Survive the cold zone and use the EXIT.");
    DrawText(Objective,FLinearColor::Yellow,20,150,GEngine->GetSmallFont(),1.15f);
    const FString Prompt=P->GetInteractionPrompt().ToString();
    if (!Prompt.IsEmpty())
        DrawText(Prompt,FLinearColor::Yellow,X-230,Y+30,GEngine->GetSmallFont(),1.45f);
}
