#include "Progression/GreyGameInstance.h"
#include "Progression/GreyMetaSave.h"
#include "Kismet/GameplayStatics.h"

namespace { const FString SaveSlot = TEXT("ThresholdRunMeta_v1"); }
void UGreyGameInstance::Init()
{
    Super::Init();
    Meta = Cast<UGreyMetaSave>(UGameplayStatics::LoadGameFromSlot(SaveSlot, SaveUser));
    if (!Meta) Meta = Cast<UGreyMetaSave>(UGameplayStatics::CreateSaveGameObject(UGreyMetaSave::StaticClass()));
    CurrentSeed = Meta ? Meta->NextSeed : 12345;
}
bool UGreyGameInstance::SaveMeta()
{
    const bool bSaved = Meta && UGameplayStatics::SaveGameToSlot(Meta, SaveSlot, SaveUser);
    if (!bSaved) UE_LOG(LogTemp, Error, TEXT("ThresholdRun: Could not write save slot %s"), *SaveSlot);
    return bSaved;
}
bool UGreyGameInstance::HasShortcut(FName ID) const { return Meta && Meta->Shortcuts.Contains(ID); }
int32 UGreyGameInstance::GetRunSeed() const { return CurrentSeed; }
int32 UGreyGameInstance::GetRunNumber() const { return Meta ? Meta->RunsCompleted + 1 : 1; }
bool UGreyGameInstance::UnlockShortcut(FName ID)
{
    if (!Meta || ID.IsNone() || Meta->Shortcuts.Contains(ID)) return false;
    Meta->Shortcuts.Add(ID); SaveMeta(); return true;
}
bool UGreyGameInstance::UnlockBlueprint(FName ID)
{
    if (!Meta || ID.IsNone() || Meta->Blueprints.Contains(ID)) return false;
    Meta->Blueprints.Add(ID); SaveMeta(); return true;
}
bool UGreyGameInstance::UnlockKnowledge(FName ID)
{
    if (!Meta || ID.IsNone() || Meta->Knowledge.Contains(ID)) return false;
    Meta->Knowledge.Add(ID); SaveMeta(); return true;
}
void UGreyGameInstance::CompleteRun(bool bVictory)
{
    if (!Meta) return;
    ++Meta->RunsCompleted;
    if (bVictory) ++Meta->Victories;
    CurrentSeed = (CurrentSeed + 7919) & 0x7fffffff;
    Meta->NextSeed = CurrentSeed;
    RunMessage = bVictory ? TEXT("ESCAPED. Knowledge retained. A new run begins.")
                          : TEXT("YOU DIED. Temporary progress lost; shortcuts retained.");
    SaveMeta();
}
