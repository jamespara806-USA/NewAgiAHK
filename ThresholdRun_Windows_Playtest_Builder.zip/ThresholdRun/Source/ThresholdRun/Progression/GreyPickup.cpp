#include "Progression/GreyPickup.h"
#include "Progression/GreyGameInstance.h"
#include "Survival/SurvivalVitals.h"
#include "Components/StaticMeshComponent.h"
#include "Components/TextRenderComponent.h"
#include "UObject/ConstructorHelpers.h"
AGreyPickup::AGreyPickup()
{
    Visual = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PickupMesh")); SetRootComponent(Visual);
    static ConstructorHelpers::FObjectFinder<UStaticMesh> Sphere(TEXT("/Engine/BasicShapes/Sphere.Sphere"));
    if (Sphere.Succeeded()) Visual->SetStaticMesh(Sphere.Object);
    Visual->SetRelativeScale3D(FVector(0.45f)); Visual->SetCollisionProfileName(TEXT("BlockAll"));
    Caption = CreateDefaultSubobject<UTextRenderComponent>(TEXT("Label")); Caption->SetupAttachment(Visual);
    Caption->SetRelativeLocation(FVector(0,0,100)); Caption->SetWorldSize(25);
    Caption->SetTextRenderColor(FColor::Yellow); Caption->SetHorizontalAlignment(EHTA_Center);
}
void AGreyPickup::Configure(EPickupKind NewKind, FName NewID, float NewAmount)
{
    Kind=NewKind; PersistentID=NewID; RestoreAmount=NewAmount;
    const TCHAR* Label=TEXT("ENERGY");
    switch(Kind)
    {
        case EPickupKind::Oxygen: Label=TEXT("OXYGEN"); break;
        case EPickupKind::Warmth: Label=TEXT("WARMTH"); break;
        case EPickupKind::Shortcut: Label=TEXT("PERMANENT SHORTCUT"); break;
        case EPickupKind::Blueprint: Label=TEXT("BLUEPRINT"); break;
        case EPickupKind::Knowledge: Label=TEXT("LORE"); break;
        default: break;
    }
    Caption->SetText(FText::FromString(FString(Label)));
}
bool AGreyPickup::CanInteract_Implementation(APawn* Pawn) const
{ return Pawn && !IsActorBeingDestroyed(); }
FText AGreyPickup::InteractionLabel_Implementation(APawn*) const
{ return FText::FromString(FString::Printf(TEXT("Press E: collect %s"), *Caption->Text.ToString())); }
void AGreyPickup::Interact_Implementation(APawn* Pawn)
{
    if (!CanInteract_Implementation(Pawn)) return;
    UGreyGameInstance* GI = Cast<UGreyGameInstance>(GetGameInstance());
    USurvivalVitals* V = Pawn->FindComponentByClass<USurvivalVitals>();
    bool bConsumed = false;
    switch(Kind)
    {
        case EPickupKind::Energy: if (V) {V->Restore(RestoreAmount,0,0); bConsumed=true;} break;
        case EPickupKind::Oxygen: if (V) {V->Restore(0,RestoreAmount,0); bConsumed=true;} break;
        case EPickupKind::Warmth: if (V) {V->Restore(0,0,RestoreAmount); bConsumed=true;} break;
        case EPickupKind::Shortcut: if(GI){GI->UnlockShortcut(PersistentID);bConsumed=true;}break;
        case EPickupKind::Blueprint: if(GI){GI->UnlockBlueprint(PersistentID);bConsumed=true;}break;
        case EPickupKind::Knowledge: if(GI){GI->UnlockKnowledge(PersistentID);bConsumed=true;}break;
    }
    if (bConsumed) { OnCollected(); Destroy(); }
}
