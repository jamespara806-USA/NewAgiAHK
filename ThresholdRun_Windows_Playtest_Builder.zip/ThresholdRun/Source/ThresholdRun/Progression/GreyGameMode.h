#pragma once
#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "GreyGameMode.generated.h"
UCLASS()
class THRESHOLDRUN_API AGreyGameMode : public AGameModeBase
{
    GENERATED_BODY()
public:
    AGreyGameMode();
    virtual void BeginPlay() override;
    UFUNCTION(BlueprintCallable) void EndRun(bool bVictory);
private:
    bool bEnding = false;
    FTimerHandle ReloadTimer;
    void ReloadLevel();
};
