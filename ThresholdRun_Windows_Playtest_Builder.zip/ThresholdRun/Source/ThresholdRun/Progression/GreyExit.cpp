#include "Progression/GreyExit.h"
#include "Progression/GreyGameMode.h"
#include "Components/StaticMeshComponent.h"
#include "Components/TextRenderComponent.h"
#include "UObject/ConstructorHelpers.h"
AGreyExit::AGreyExit()
{
    Visual = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Exit")); SetRootComponent(Visual);
    static ConstructorHelpers::FObjectFinder<UStaticMesh> Cube(TEXT("/Engine/BasicShapes/Cube.Cube"));
    if (Cube.Succeeded()) Visual->SetStaticMesh(Cube.Object);
    Visual->SetRelativeScale3D(FVector(1.0f,1.4f,2.4f)); Visual->SetCollisionProfileName(TEXT("BlockAll"));
    Caption=CreateDefaultSubobject<UTextRenderComponent>(TEXT("Caption"));Caption->SetupAttachment(Visual);
    Caption->SetRelativeLocation(FVector(0,0,140));Caption->SetWorldSize(35);
    Caption->SetTextRenderColor(FColor::Green);Caption->SetText(FText::FromString(TEXT("EXIT [E]")));
}
bool AGreyExit::CanInteract_Implementation(APawn* Pawn) const { return Pawn!=nullptr; }
FText AGreyExit::InteractionLabel_Implementation(APawn*) const { return FText::FromString(TEXT("Press E: escape and start a new run")); }
void AGreyExit::Interact_Implementation(APawn*)
{
    if (AGreyGameMode* GM = Cast<AGreyGameMode>(GetWorld()->GetAuthGameMode())) GM->EndRun(true);
}
