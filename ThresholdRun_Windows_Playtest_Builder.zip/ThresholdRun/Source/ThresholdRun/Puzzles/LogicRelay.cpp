#include "Puzzles/LogicRelay.h"
#include "Components/StaticMeshComponent.h"
ALogicRelay::ALogicRelay()
{
    Visual->SetRelativeScale3D(FVector(0.6f));
    SetCaptionText(TEXT("RELAY: SWITCH + PLATE"));
}
void ALogicRelay::Configure(const TArray<APuzzleMechanism*>& NewInputs, bool bAll)
{
    for (APuzzleMechanism* M : Inputs) if (IsValid(M)) M->OnStateChanged.RemoveDynamic(this, &ALogicRelay::InputChanged);
    Inputs.Empty(); bRequireAll = bAll;
    for (APuzzleMechanism* M : NewInputs)
        if (IsValid(M) && M != this && !Inputs.Contains(M))
        { Inputs.Add(M); M->OnStateChanged.AddDynamic(this, &ALogicRelay::InputChanged); }
    Reevaluate();
}
void ALogicRelay::InputChanged(APuzzleMechanism*, EPuzzleState, EPuzzleState) { Reevaluate(); }
void ALogicRelay::Reevaluate()
{
    if (IsTriggered() || Inputs.IsEmpty()) return;
    bool bSatisfied = bRequireAll;
    for (const APuzzleMechanism* M : Inputs)
    {
        const bool bReady = IsValid(M) && M->IsTriggered();
        if (bRequireAll) bSatisfied &= bReady;
        else bSatisfied |= bReady;
    }
    if (bSatisfied && TryActivate()) TryTrigger(); // latch permanently this run
}
void ALogicRelay::EndPlay(const EEndPlayReason::Type Reason)
{
    for (APuzzleMechanism* M : Inputs)
        if (IsValid(M)) M->OnStateChanged.RemoveDynamic(this, &ALogicRelay::InputChanged);
    Super::EndPlay(Reason);
}
