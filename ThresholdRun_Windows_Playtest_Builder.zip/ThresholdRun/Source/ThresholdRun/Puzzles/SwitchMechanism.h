#pragma once
#include "CoreMinimal.h"
#include "Puzzles/PuzzleMechanism.h"
#include "Interaction/PrototypeInteractable.h"
#include "SwitchMechanism.generated.h"
UCLASS(Blueprintable)
class THRESHOLDRUN_API ASwitchMechanism : public APuzzleMechanism, public IPrototypeInteractable
{
    GENERATED_BODY()
public:
    ASwitchMechanism();
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Puzzle") float EnergyCost = 12.f;
    virtual bool CanInteract_Implementation(APawn* Pawn) const override;
    virtual FText InteractionLabel_Implementation(APawn* Pawn) const override;
    virtual void Interact_Implementation(APawn* Pawn) override;
    UFUNCTION(BlueprintImplementableEvent, Category="Puzzle") void OnSwitchUsed();
};
