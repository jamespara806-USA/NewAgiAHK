#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Puzzles/PuzzleMechanism.h"
#include "GreyGate.generated.h"
class UStaticMeshComponent;
class UTextRenderComponent;
UCLASS(Blueprintable)
class THRESHOLDRUN_API AGreyGate : public AActor
{
    GENERATED_BODY()
public:
    AGreyGate();
    UPROPERTY(VisibleAnywhere) TObjectPtr<UStaticMeshComponent> Barrier;
    UPROPERTY(VisibleAnywhere) TObjectPtr<UTextRenderComponent> Caption;
    UPROPERTY(BlueprintReadOnly) bool bOpen = false;
    UFUNCTION(BlueprintCallable) void Configure(APuzzleMechanism* InSource, FName InShortcut);
    UFUNCTION(BlueprintCallable) void RefreshGate();
    UFUNCTION(BlueprintImplementableEvent) void OnGateOpened();
protected:
    virtual void EndPlay(const EEndPlayReason::Type Reason) override;
private:
    UPROPERTY() TObjectPtr<APuzzleMechanism> Source;
    UPROPERTY() FName ShortcutID;
    UFUNCTION() void SourceChanged(APuzzleMechanism* Mechanism, EPuzzleState Before, EPuzzleState After);
};
