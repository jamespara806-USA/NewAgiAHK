#include "Puzzles/PressurePlate.h"
#include "Components/StaticMeshComponent.h"
#include "Components/TextRenderComponent.h"
#include "Components/BoxComponent.h"
#include "GameFramework/Pawn.h"
#include "Components/PrimitiveComponent.h"
APressurePlate::APressurePlate()
{
    Visual->SetRelativeScale3D(FVector(1.7f,1.7f,0.15f));
    PressureArea = CreateDefaultSubobject<UBoxComponent>(TEXT("PressureArea"));
    PressureArea->SetupAttachment(Visual);
    PressureArea->SetRelativeLocation(FVector(0,0,80));
    PressureArea->SetBoxExtent(FVector(95,95,95));
    PressureArea->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
    PressureArea->SetCollisionResponseToAllChannels(ECR_Ignore);
    PressureArea->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);
    PressureArea->SetGenerateOverlapEvents(true);
    Caption->SetAbsolute(false,false,true);
    Caption->SetRelativeLocation(FVector(0,0,780));
    SetCaptionText(TEXT("PRESSURE PLATE"));
}
void APressurePlate::BeginPlay()
{
    Super::BeginPlay();
    PressureArea->OnComponentBeginOverlap.AddDynamic(this, &APressurePlate::OnEnter);
    PressureArea->OnComponentEndOverlap.AddDynamic(this, &APressurePlate::OnExit);
}
void APressurePlate::OnEnter(UPrimitiveComponent*, AActor* Actor, UPrimitiveComponent*, int32, bool, const FHitResult&)
{
    if (!Cast<APawn>(Actor)) return;
    const TWeakObjectPtr<AActor> Key(Actor);
    if (Pressers.Contains(Key)) return;
    Pressers.Add(Key);
    if (State == EPuzzleState::Ready) { TryActivate(); TryTrigger(); }
}
void APressurePlate::OnExit(UPrimitiveComponent*, AActor* Actor, UPrimitiveComponent*, int32)
{
    Pressers.Remove(TWeakObjectPtr<AActor>(Actor));
    if (Pressers.IsEmpty()) ResetMechanism();
}
