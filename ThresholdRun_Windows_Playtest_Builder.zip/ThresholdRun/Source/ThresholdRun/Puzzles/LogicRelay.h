#pragma once
#include "CoreMinimal.h"
#include "Puzzles/PuzzleMechanism.h"
#include "LogicRelay.generated.h"
UCLASS(Blueprintable)
class THRESHOLDRUN_API ALogicRelay : public APuzzleMechanism
{
    GENERATED_BODY()
public:
    ALogicRelay();
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Puzzle") bool bRequireAll = true;
    UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category="Puzzle") TArray<TObjectPtr<APuzzleMechanism>> Inputs;
    UFUNCTION(BlueprintCallable) void Configure(const TArray<APuzzleMechanism*>& NewInputs, bool bAll);
    UFUNCTION(BlueprintCallable) void Reevaluate();
protected:
    virtual void EndPlay(const EEndPlayReason::Type Reason) override;
private:
    UFUNCTION() void InputChanged(APuzzleMechanism* Source, EPuzzleState Before, EPuzzleState After);
};
