#pragma once
#include "CoreMinimal.h"
#include "Puzzles/PuzzleMechanism.h"
#include "PressurePlate.generated.h"
class UBoxComponent;
UCLASS(Blueprintable)
class THRESHOLDRUN_API APressurePlate : public APuzzleMechanism
{
    GENERATED_BODY()
public:
    APressurePlate();
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly) TObjectPtr<UBoxComponent> PressureArea;
protected:
    virtual void BeginPlay() override;
private:
    UFUNCTION() void OnEnter(UPrimitiveComponent*, AActor*, UPrimitiveComponent*, int32, bool, const FHitResult&);
    UFUNCTION() void OnExit(UPrimitiveComponent*, AActor*, UPrimitiveComponent*, int32);
    TSet<TWeakObjectPtr<AActor>> Pressers;
};
