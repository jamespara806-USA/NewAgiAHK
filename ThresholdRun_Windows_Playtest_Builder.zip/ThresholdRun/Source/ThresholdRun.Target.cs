using UnrealBuildTool;
using System.Collections.Generic;
public class ThresholdRunTarget : TargetRules
{
    public ThresholdRunTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Game;
        DefaultBuildSettings = BuildSettingsVersion.V5;
        IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
        ExtraModuleNames.Add("ThresholdRun");
    }
}
